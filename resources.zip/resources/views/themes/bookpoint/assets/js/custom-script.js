$(function (){
    $(document).ready(function (){
        $('.footer-widget ul.footer-link-list li').addClass('list');
    });
});
