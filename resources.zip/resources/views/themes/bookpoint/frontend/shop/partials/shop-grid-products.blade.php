<div class="shop-grid-contents">
    @include(include_theme_path('shop.partials.filter-partials.shop-filters'))

    <div class="grid-product-list">
        @include(include_theme_path('shop.partials.product-partials.grid-products'))
    </div>

    <div class="list-product-list">
        @include(include_theme_path('shop.partials.product-partials.list-products'))
    </div>
</div>
