<div id="description" class="tab-content-item active">
    <div class="description-tab-wrapper">
        <div class="row align-items-center">
            <div class="col-lg-12 mt-4">
                <div class="single-description-tab">
                    <div class="single-description-tab-content">
                        {!! $product->description !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
