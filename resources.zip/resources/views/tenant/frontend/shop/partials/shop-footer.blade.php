{!! render_frontend_sidebar('shop_footer',['column' => false]) !!}
