@include('landlord.frontend.partials.header')
@yield('content')
@include('landlord.frontend.partials.footer')
